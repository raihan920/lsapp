-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 30, 2018 at 12:48 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lsapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_07_22_041102_create_posts_table', 1),
(4, '2018_07_24_102256_add_user_id_to_posts_table', 2),
(5, '2018_07_30_051504_add_cover_image_to_posts', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `cover_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`, `user_id`, `cover_image`) VALUES
(1, 'Post One', 'This is post body one', '2018-07-21 22:52:01', '2018-07-21 22:52:01', 4, 'noimage.jpeg'),
(2, 'Post Two', 'This is post body two', '2018-07-21 22:53:26', '2018-07-21 22:53:26', 2, 'noimage.jpeg'),
(3, 'Sapiente itaque maxime molestiae asperiores error perferendis nisi tempore.', 'Qui non nesciunt maiores enim. Rerum in ipsum id assumenda et soluta. Quos ut est animi labore quam in nulla. Occaecati et aspernatur dolor vel ipsa. Non ipsam beatae in distinctio ratione earum quaerat qui.\n\nDolorum voluptatem accusantium dolor quis ipsum. Voluptatem culpa aliquam officiis aut quisquam consectetur placeat. Debitis natus perferendis illum porro incidunt distinctio. Quas qui incidunt temporibus veritatis vel laudantium consequuntur.\n\nEst ab autem temporibus aperiam qui exercitationem aut. Consequuntur optio dolorem quo. Dolor qui quaerat similique et hic saepe est autem.\n\nDignissimos distinctio asperiores porro consectetur quasi doloribus dolorum. At voluptatum perferendis tenetur reiciendis. Ipsa quos tempora doloremque iusto nobis neque.\n\nAperiam quasi omnis repellendus distinctio. Repudiandae nulla et omnis optio. Omnis tenetur dicta sed voluptas fugiat. Ut provident qui amet facere sunt commodi.\n\nEa est repudiandae repudiandae enim quibusdam impedit. Similique aspernatur nesciunt mollitia cumque in doloribus. Corrupti minima repellendus omnis veritatis iste.\n\nSunt nemo accusamus ea qui rem sequi accusamus. Aperiam rerum natus soluta sint atque est voluptate. Consequatur quisquam vel dolore molestiae consequatur qui eius consectetur. Sed et dolores sapiente quis.', '2018-07-22 02:10:04', '2018-07-22 02:10:04', 7, 'noimage.jpeg'),
(4, 'Aperiam qui accusantium labore ullam.', 'Non amet consequatur non eius cum vitae. Et voluptate magnam voluptate voluptas. Nulla odit iste alias harum rerum rem temporibus. Impedit et et cumque pariatur quisquam quas eos.\n\nAutem eligendi impedit unde repudiandae. In quas quo magnam ea. Ratione consequatur illo quisquam quia nam. Quia ipsa recusandae dolore odit facilis.\n\nPraesentium velit voluptas molestiae sunt nemo ipsum dolores. Molestiae autem consequatur sit quia mollitia rerum quos. Tempore sapiente id unde odio delectus est. Repellendus et omnis aut et qui. Suscipit velit qui voluptatem nihil quo.\n\nPraesentium aliquam animi qui ut minima assumenda. Aut velit unde id qui. Accusantium quibusdam est soluta maxime enim quae. Necessitatibus id architecto quam numquam sunt ducimus aut.', '2018-07-22 02:10:04', '2018-07-22 02:10:04', 1, 'noimage.jpeg'),
(5, 'Repellat cumque sunt ut dolores perspiciatis non quod ea non.', 'Molestias sapiente fugiat recusandae tenetur. Non est quaerat dicta inventore assumenda est omnis. Rem alias harum veritatis distinctio nam laudantium et. Porro corporis est et amet.\n\nNisi consectetur autem rerum eaque temporibus. Voluptatem dolorem repudiandae dolores necessitatibus debitis est. Veritatis unde autem omnis ullam assumenda necessitatibus.\n\nOccaecati aut iure rerum eaque rerum ad. Ut aperiam rerum voluptatem quam. Pariatur quae unde culpa dolor. Voluptatem iste id ea quis. Inventore et ut voluptate cupiditate.\n\nAdipisci qui pariatur facilis incidunt aut ipsam similique. Pariatur qui ab ad itaque. Provident est consequatur odit rerum sed aut ut.\n\nEt non temporibus voluptatem sint repudiandae omnis. Nesciunt qui et delectus. Porro voluptas voluptatem id et praesentium et.', '2018-07-22 02:10:04', '2018-07-22 02:10:04', 9, 'noimage.jpeg'),
(7, 'Consectetur totam dolore omnis sequi a excepturi quos rerum.', 'Laudantium adipisci est sit hic voluptatem et. Et omnis voluptate quo quas eos. Ea quod consequatur ut. Rerum cupiditate rerum est tempore fuga optio.\n\nAb quo libero odit et. Rem molestiae velit porro et. Numquam sit modi exercitationem est voluptatem qui. Assumenda porro autem molestiae et deleniti. Officia iusto deserunt nam.\n\nId aut aspernatur officia molestiae asperiores nisi sit quia. Tenetur nam et facilis ad neque eaque quia. Voluptatem debitis sapiente porro est odio. Reiciendis reprehenderit accusamus totam quia dolore rerum.', '2018-07-22 02:10:05', '2018-07-22 02:10:05', 7, 'noimage.jpeg'),
(8, 'Quis minima provident velit illum quisquam placeat fuga ut recusandae.', 'Expedita aspernatur omnis in occaecati et. Alias repudiandae corrupti numquam est magnam ut. Blanditiis consequuntur voluptas qui odit est quibusdam. Magnam iure ut iure ea magni vel vel.\n\nMaxime sed voluptatem aperiam cupiditate sit esse iste et. Unde error iure repellat neque voluptatem est itaque. Rerum iure et sed sit. Vitae tenetur ut et nostrum mollitia.\n\nEst sed dolor deserunt tenetur qui esse sint. Dolorem officiis assumenda ut quis unde occaecati.\n\nEt exercitationem omnis necessitatibus nostrum consequatur. Neque id et ea voluptatibus. Aut et asperiores eligendi quas quo odio.', '2018-07-22 02:10:05', '2018-07-22 02:10:05', 6, 'noimage.jpeg'),
(9, 'Illo rerum incidunt veritatis cupiditate voluptas mollitia.', 'Error placeat dignissimos distinctio reiciendis rerum alias. Dolorum esse in cumque. Similique sequi est nihil in omnis. Rerum iure porro est porro non commodi pariatur. Accusamus sapiente et porro dolor et culpa doloremque.\n\nUnde rerum vel nam iusto odit dolores esse. Maxime enim inventore aut modi. Blanditiis consequatur eum laudantium et.\n\nVoluptatum porro eius quia similique totam non nulla. Asperiores sed qui ullam accusamus facere. Corporis nulla vel maiores aut consequuntur perferendis nostrum. Sapiente sed quod aut vel esse consectetur.\n\nSit saepe corrupti neque vitae aliquid. Voluptas dolor ut et. Harum dolores rem culpa facere architecto. Impedit odio voluptas magni distinctio.', '2018-07-22 02:10:05', '2018-07-22 02:10:05', 6, 'noimage.jpeg'),
(10, 'Enim eos veritatis a maiores eius eveniet.', 'Tenetur accusamus possimus omnis quis repellendus illo. Eos voluptas at aperiam laboriosam quis. Non corrupti quae fugiat voluptatem ipsum laudantium qui.\n\nSimilique quos placeat dignissimos vel unde. Dolore qui unde culpa eaque adipisci. Molestias accusantium commodi ea consequuntur pariatur in repellat.', '2018-07-22 02:10:05', '2018-07-22 02:10:05', 5, 'noimage.jpeg'),
(11, 'Animi quo facilis.', 'Quos molestiae nostrum error quod excepturi vel. Voluptate sit voluptas culpa eaque. Quos excepturi dignissimos ut adipisci molestias. Nam maxime quas odio nihil nostrum. Aliquid sapiente natus deleniti dolore.\n\nIncidunt dolorum ea autem molestias quo laborum. Eum corporis dolorem recusandae distinctio cupiditate tempora. Quis mollitia quos occaecati et similique velit. Numquam iure laboriosam quae.\n\nMolestiae eius iste ratione voluptates. Dolores possimus ea deserunt nihil. Consectetur fuga quas minima est harum recusandae. Doloribus accusantium dolores quam fugit.\n\nEt occaecati maxime culpa iure. Aperiam error qui voluptas. Repellat facilis non vero temporibus commodi error.\n\nUt dicta quidem aut sint accusamus est molestiae. Voluptates praesentium ducimus quaerat omnis. Voluptatem ipsam a impedit eaque blanditiis.\n\nDolores iusto voluptas aut sunt in facilis quas. Aut maiores quo eum quia. Autem vero rerum aut nostrum et veniam in.\n\nAliquam ducimus est non cum facere minima. Accusamus ab voluptas repellat aliquid. Quae aut voluptatem rerum ut. Ut et reiciendis adipisci.\n\nEnim ratione minus ea et qui et ut sit. Incidunt voluptatum et quae praesentium. Et debitis et qui est accusamus ut rerum. Officia voluptas officiis est deleniti sunt.\n\nDolorem alias nemo vel qui. Tenetur facilis reiciendis consequuntur doloremque culpa voluptatum. Similique cupiditate dolorem provident ratione culpa dignissimos.', '2018-07-22 02:10:05', '2018-07-22 02:10:05', 6, 'noimage.jpeg'),
(12, 'Dolor fuga quia qui cumque dicta sit.', 'Quia qui delectus qui assumenda. Velit commodi ullam aut quis ut. Iusto alias nam nihil et.\n\nCumque consequatur sed sed ut. Quis nihil iure quae blanditiis non officiis aut.\n\nQui quia corporis non aliquam tempore. Fugiat inventore est cum aperiam quia. Rerum dignissimos quas possimus soluta veniam quia. Et blanditiis tenetur exercitationem provident est officia.', '2018-07-22 02:10:05', '2018-07-22 02:10:05', 6, 'noimage.jpeg'),
(13, 'Quia ipsa quo pariatur quisquam repellendus quae assumenda.', 'Laudantium quasi tempore commodi provident aut quasi excepturi. Earum saepe et sapiente pariatur. Labore accusantium est qui voluptates et aut. Ut unde qui blanditiis et fugit voluptatibus et.\n\nIncidunt vel est illum illum voluptas sed. Praesentium corporis quis saepe perspiciatis ullam. Dolorum quisquam iste sed velit commodi iure. Reiciendis amet deleniti doloribus eius.\n\nRem est facilis repellendus qui amet optio. Et voluptas sunt ut reiciendis. Voluptatem id sed et nostrum.\n\nFugiat eveniet maiores accusamus non quas. Architecto omnis quam sit et vero maxime. Minima qui aut unde eos.\n\nAperiam voluptate ea officiis quia. A qui laboriosam aut quis. Voluptatem et asperiores sed quia alias qui.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 8, 'noimage.jpeg'),
(14, 'Molestias amet quia sed ut labore exercitationem.', 'Laborum laudantium harum reiciendis. Quos sequi qui aspernatur sint. Eaque et perferendis aliquam non. Delectus unde consectetur itaque eum soluta. Voluptas et perspiciatis quia est fugiat reprehenderit aliquid.\n\nDolorum debitis harum veritatis quo. Velit sequi mollitia temporibus non eos id. Mollitia molestiae unde voluptatum qui omnis ea.\n\nSunt necessitatibus nisi accusantium porro quod facilis. Accusamus nam id rerum. Eum cupiditate pariatur cupiditate. Ut molestiae impedit unde voluptatibus quibusdam.\n\nVel quia fuga voluptates deserunt mollitia iusto veniam. Perferendis nesciunt blanditiis consectetur velit maiores nesciunt soluta. Est commodi in tempora commodi consequatur dicta. Est qui ullam temporibus dolorem et.\n\nVeritatis quia ipsum omnis eligendi et natus. Vel sequi nulla repellat laborum reiciendis nemo facilis maxime. Autem esse doloribus est.\n\nSit ut officia in corrupti corrupti. Sit perspiciatis velit sapiente quos debitis iusto dolorem quia. Aut est sunt qui quia et dolorem est aliquid.\n\nOfficiis soluta soluta omnis ea. Id nobis numquam deserunt quia qui corrupti et. Cumque numquam culpa aut quidem cum laudantium voluptatem.\n\nVoluptatibus sed atque nemo eos praesentium fuga rerum. Quae saepe excepturi est aperiam vitae. Impedit error eos architecto expedita animi commodi.\n\nUt rerum neque sint est illum. Rerum ut id et laudantium necessitatibus aliquam. Ab minima in voluptas totam officia dolores. Saepe mollitia veniam numquam earum vel asperiores.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 4, 'noimage.jpeg'),
(15, 'Eum tempore ea minus molestiae est et ab numquam.', 'Perspiciatis eum quo perspiciatis alias quae. In optio a eum eos. Voluptas quia quo enim et.\n\nFacilis repudiandae asperiores quaerat mollitia autem et. Neque consequatur nihil quos et cupiditate pariatur incidunt. Dolorum nisi perferendis voluptas aperiam.\n\nEt eius nesciunt officia consequatur ratione accusantium quaerat numquam. Provident repudiandae enim eligendi illum aut sit.\n\nLabore eaque quidem perferendis accusantium cum. Impedit corrupti dicta praesentium soluta laudantium aspernatur nihil. Sint expedita ab possimus expedita. Eos aut non quam porro illum nesciunt at et.\n\nFacilis sit corporis sit occaecati eos ab beatae. Vero accusamus consequuntur explicabo id labore eos. Officia quas officiis et autem optio. Et similique incidunt id aut ex odit. Provident reiciendis quidem saepe maxime iusto sit at qui.\n\nAccusamus perspiciatis quo animi. Molestiae error quibusdam quia explicabo assumenda aut beatae. Ab ducimus excepturi deleniti sit aliquam ab esse. Quibusdam qui nobis occaecati doloribus sit.\n\nMolestias non mollitia labore dolores eius quis. Et odio accusantium maiores nesciunt alias quae. Repudiandae qui cupiditate non aut. Qui saepe provident vero iste nostrum numquam.\n\nEt itaque odit nostrum pariatur. Dolores ipsum dicta aliquid in id quos natus.\n\nQuo et vitae quasi ullam. Doloremque fugiat consequatur est. Repellat adipisci error est quos cupiditate ut officiis.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 4, 'noimage.jpeg'),
(16, 'Adipisci ducimus sequi maxime exercitationem aut.', 'Iusto accusantium fugiat perferendis rem sed molestiae ut. Et vitae illo praesentium quo. Consequatur nisi earum id aliquam. Reiciendis adipisci tempore dolor dolorem deleniti quasi est.\n\nSit autem ipsa suscipit harum qui deserunt eveniet. Aliquid voluptatem dicta sit sed laboriosam laborum. Expedita beatae consequatur placeat harum repellendus sapiente.\n\nVeritatis consequatur aperiam fugiat omnis iusto cum. Et ut accusantium quibusdam alias ratione voluptas. Autem illum laudantium magnam dolorem iusto velit optio. Unde accusamus debitis dolorum dolore.\n\nA omnis eius dignissimos dolor necessitatibus incidunt aut esse. Ut ut enim et qui ut. A quis quis est nostrum tenetur quis nobis.\n\nDolorem in est modi quisquam incidunt molestias. Qui odio ut enim aut quis. Error beatae sed nemo et voluptates autem maxime.\n\nEt aspernatur ipsum repellendus qui molestias consequatur voluptatem qui. Eligendi nostrum tempora assumenda ducimus eum qui. Quas tempore dolor ab sint occaecati harum. Consequatur voluptate explicabo quod itaque eos vel aliquid.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 7, 'noimage.jpeg'),
(17, 'Explicabo quia accusamus distinctio voluptatibus.', '<p>Ut ut qui omnis voluptas incidunt quisquam voluptatem. Adipisci sunt odit et libero sit earum est. Dicta quia doloribus voluptates facere. Saepe officia ut mollitia quia assumenda dolorem. Et est quam quasi rem. Tempora perspiciatis sint adipisci nihil ipsa nostrum. Voluptatem saepe consequatur a distinctio sit sed omnis. Accusantium est atque rem eum qui amet odit in. Ut dolorem consectetur sint. Reprehenderit nostrum et consectetur ut. Omnis voluptatem voluptas neque nobis dolore animi. Enim eligendi maiores in est pariatur eius. Omnis molestiae velit animi sed tenetur. Nostrum quam aut ut quas consectetur ab quo. Minima sunt autem architecto consequatur eos non nisi quisquam. Voluptatibus sed quo qui dolore vitae repellendus commodi rerum. Fugit corrupti dicta rem natus ut ratione nihil. Dolores consequuntur alias sit id.</p>', '2018-07-22 03:53:36', '2018-07-24 02:18:10', 5, 'noimage.jpeg'),
(18, 'Inventore ipsa doloribus libero officiis qui quia est.', 'Voluptatem velit eos iste eum. Sint eius pariatur sit quia veritatis.\n\nMaxime nisi incidunt doloribus est quis corrupti. Quod qui eveniet quis eligendi magnam quidem quidem. Cumque quia optio architecto. Voluptatibus impedit blanditiis iure harum ad est.\n\nEum occaecati facilis dolores ut. Itaque recusandae dolores quasi eligendi sed. Ullam vel vero ut officia. Eos sint neque numquam sapiente molestiae quo.\n\nReprehenderit vitae sit aut qui est aut impedit. Iste nulla quasi sint quia. Quo quo et vero sed quam. Veniam aut rem vel nemo.\n\nAb facilis accusamus alias iure. Eius sed ex architecto consequuntur nihil. Velit exercitationem iste qui.\n\nSed distinctio et possimus atque. Et et dolorum id voluptatibus eum excepturi. Quia nam laudantium voluptatem blanditiis unde modi. Aperiam quo nobis sunt minima eos aspernatur labore.\n\nVel odio enim voluptas ullam accusamus. Porro repellat voluptatum ut est. Consequuntur reprehenderit maxime ut itaque debitis. Suscipit unde delectus nisi omnis.\n\nVoluptatum corrupti minus minus officia. Voluptatum quo sit adipisci asperiores fuga optio. Alias vel voluptatem qui labore enim ipsa. Molestias et voluptas debitis laboriosam velit quibusdam. Maxime qui nostrum omnis similique saepe iusto veritatis.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 2, 'noimage.jpeg'),
(19, 'Assumenda alias quo quod aut eaque.', 'Voluptatem officiis qui ipsum molestiae cum. Qui voluptates consequatur repudiandae assumenda esse autem et. Non nam praesentium et. Rerum rerum hic id. Ratione distinctio qui deleniti reiciendis.\n\nVitae nulla quis minima voluptatem. Ex cum quia asperiores vero nam magnam. Et voluptas voluptas nobis autem nam. Qui magnam nostrum laboriosam ullam.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 2, 'noimage.jpeg'),
(20, 'Perspiciatis sequi illo cum possimus cupiditate.', 'Assumenda laborum velit explicabo incidunt dolorem aliquid voluptate. Beatae soluta quo non eveniet enim consequatur. Optio aliquam et quia impedit quibusdam.\n\nDelectus suscipit cum praesentium velit. Sequi et quasi fugit fuga ipsum ex ut occaecati.\n\nPerferendis eos mollitia aut neque sunt aut natus consequatur. Sint dolorem aut est minima inventore omnis. Laudantium incidunt enim quia minus ea molestiae beatae commodi. Incidunt animi dolores explicabo quisquam. Qui facere sed nulla amet et fugit.\n\nAut deserunt velit nostrum et. Sed ratione dicta molestiae error excepturi vero. Ipsum tempore error deserunt dolorem sequi.\n\nEsse blanditiis repellendus adipisci eaque quam. Totam recusandae aut sapiente dolor. Fugiat minima consequatur temporibus quo aut. Ipsa iusto molestiae velit ut officiis.\n\nEt pariatur voluptatibus veniam harum magni commodi commodi. Vel ut rerum eveniet quis. Non ullam ut facilis voluptas deserunt aliquid cumque.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 3, 'noimage.jpeg'),
(21, 'Ut temporibus et blanditiis recusandae vero modi.', 'Eveniet et omnis veniam velit sed reiciendis autem. Repudiandae et facilis aut est odio ut.\n\nEst est sed facilis adipisci. Consequatur suscipit animi et amet quia qui. A quia aspernatur et tempora qui tenetur aspernatur.\n\nVeritatis dolorem quae omnis nemo voluptates. Magnam natus sunt quaerat est et. Sint ea eveniet sint nostrum velit eius corporis fugiat.\n\nFugit quaerat totam nesciunt ut pariatur quia quia. Sint beatae id ipsum inventore aut. Cumque sint hic culpa et. Quia aliquid numquam iure rerum beatae aut nisi assumenda.\n\nDolores explicabo commodi aperiam in molestias nulla. Pariatur quibusdam excepturi quia et ut. Recusandae libero repellendus excepturi illum sequi placeat. Aliquam omnis natus id.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 8, 'noimage.jpeg'),
(22, 'Iure assumenda rerum et a perferendis quam.', 'Suscipit est fugit cupiditate ullam. Quod ea in ad nihil aperiam a. Debitis similique quos repellendus et voluptatem. Odio quaerat perferendis illum animi et.\n\nAut perspiciatis velit fugit incidunt. Qui autem tenetur autem ut esse. Animi voluptatem fugit vel quidem aspernatur.\n\nEnim voluptatem incidunt cupiditate tempore repellat optio odio. Quam fugit doloribus sunt. Nam omnis dolorum veritatis voluptas sit nulla ut.\n\nNostrum ut nam nihil. Dignissimos qui alias sed expedita rerum voluptas. Ea nobis est distinctio expedita voluptate.\n\nUt quibusdam voluptas ut cum quia eum ullam. Soluta eum sunt earum. Iusto voluptas debitis omnis ea quia. Labore dolor voluptas sit ut in rerum.\n\nEius ut qui id doloremque recusandae. Fugiat voluptatem voluptatem ab quia iste quidem. Aspernatur architecto sit impedit sint.\n\nOdit voluptatem dolorum ex voluptatum vitae nisi natus. Mollitia consequuntur quae quam non.', '2018-07-22 03:53:36', '2018-07-22 03:53:36', 3, 'noimage.jpeg'),
(23, 'My Custom P0st', 'Well done!\r\n\r\nAww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.', '2018-07-23 04:33:09', '2018-07-23 04:33:09', 7, 'noimage.jpeg'),
(24, 'Rohingya Crisis', '<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:720px\">\r\n	<tbody>\r\n		<tr>\r\n			<td><a href=\"https://www.thedailystar.net/rohingya-crisis/myanmar-violates-united-nations-child-rights-pact-in-rohingya-crackdown-1609270\"><img src=\"https://assetsds.cdnedge.bluemix.net/sites/default/files/styles/medium_1/public/feature/images/800_64.jpeg?itok=_o9hDE-p\" style=\"float:left; height:153px; margin:5px; width:270px\" /></a></td>\r\n			<td>\r\n			<p><a href=\"https://www.thedailystar.net/rohingya-crisis/myanmar-violates-united-nations-child-rights-pact-in-rohingya-crackdown-1609270\">Myanmar broke UN child rights pact: Experts </a></p>\r\n\r\n			<p>Myanmar violated its obligations to the United Nations child rights convention in its crackdown on the Rohingya that led to an exodus of hundreds of thousands of people from the minority community, legal experts find.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href=\"https://www.thedailystar.net/rohingya-crisis/dhaka-wants-unsc-deliver-rohingya-issue-repatriate-myanmar-1609258\"><img src=\"https://assetsds.cdnedge.bluemix.net/sites/default/files/styles/medium_1/public/feature/images/rohingya_112.jpg?itok=AzId-SKW\" style=\"float:left; height:153px; margin:5px; width:270px\" /></a></td>\r\n			<td>\r\n			<p><a href=\"https://www.thedailystar.net/rohingya-crisis/dhaka-wants-unsc-deliver-rohingya-issue-repatriate-myanmar-1609258\">Dhaka wants UNSC to deliver on Rohingya issue </a></p>\r\n\r\n			<p>Bangladesh wants the United Nations Security Council (UNSC) to deliver on Rohingya issue to have a sustainable solution to the crisis as the body having responsibility for the maintenance of international peace and security sits on Monday.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href=\"https://www.thedailystar.net/rohingya-crisis/key-member-resigns-myanmar-advisory-panel-rohingya-crisis-1608871\"><img alt=\"Rohingya\" src=\"https://assetsds.cdnedge.bluemix.net/sites/default/files/styles/medium_1/public/feature/images/rohingya_111.jpg?itok=w4nkrXxA\" style=\"float:left; height:153px; margin:5px; width:270px\" /></a></td>\r\n			<td>\r\n			<p><a href=\"https://www.thedailystar.net/rohingya-crisis/key-member-resigns-myanmar-advisory-panel-rohingya-crisis-1608871\">Key member resigns from Myanmar advisory panel on Rohingya crisis</a></p>\r\n\r\n			<p>A key member of an international advisory panel on Myanmar&#39;s crisis-hit Rakhine state resigns, telling AFP that the Aung San Suu Kyi-appointed board risks becoming &quot;part of the problem&quot; in a conflict that forced 700,000 Rohingya Muslims to flee.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>', '2018-07-23 22:44:58', '2018-07-24 00:59:09', 8, 'noimage.jpeg'),
(25, 'Corruption in Bangladesh', '<p><strong>Introduction:</strong></p>\r\n\r\n<p>Corruption means committing crime and mischief to the country. It causes great harm to the countrymen. None escape from the harm of corruption. It is a social malady. It spreads its greedy clutches all over the country; each and every government sector of the country is affected by corruption. Government officials, clerks, secretaries and even ordinary peons, security officers and others are engaged in corruption. They take bribe from common people for giving any service. Our country, Bangladesh, has topped the list of corrupt countries five times. There is none to raise voice against the galloping corruption! Even the organizations that&nbsp;&nbsp; collects data about corruption &ndash; are themselves corrupted in a very secret way! However there are many reasons behind this corruption. The greed for power, pelf, wealth and money is the root cause of corruption. Avarice, dishonesty, nepotism and favoritism are also responsible for corruption.</p>\r\n\r\n<p><a href=\"http://www.assignmentpoint.com/wp-content/uploads/2013/09/Corruption.jpg\" target=\"_blank\"><img alt=\"Corruption\" src=\"http://www.assignmentpoint.com/wp-content/uploads/2013/09/Corruption.jpg\" style=\"height:149px; width:339px\" /></a></p>', '2018-07-25 23:55:30', '2018-07-30 04:36:06', 1, 'corruption_1532946966.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Raihan', 'raihan@gmail.com', '$2y$10$Y6aTVlSW/eMiv8u4Vax6EOfUC5z0T3X8xgAtm3SQNA85npwmriMfG', 'W2uoXmVjZ0ZkrdE80G9nsujQutbbP2lIGCHCOuqcuWio99eTszWGYjiou6OA', '2018-07-24 03:39:58', '2018-07-24 03:39:58'),
(2, 'Nahi', 'nahi@gmail.com', '$2y$10$45ky5FKFILZ1zfyExsZ.j.UIpWadtwcr9iTs7dIo15eAZYHysKwre', 'DuaAxpCftT90TzqtRb9WGp6OSEkyDnlPVTPnkCLyOvauwcqCiYzrQVP3GKaq', '2018-07-26 03:54:59', '2018-07-26 03:54:59'),
(3, 'userOne', 'userOne@gmail.com', '$2y$10$tDi6aUcH5gUWrdmbio/2mOuJxX4DFo8Nfhs1f3dIVm.h5F.EqoCT6', 'C5cAZWce5emzUjLILrzjyHQpzQwV5y9rMwAnKbL4R1CfW6sr9sCboKIiMJJz', '2018-07-26 04:23:10', '2018-07-26 04:23:10'),
(4, 'userTwo', 'userTwo@gmail.com', '$2y$10$3PlgGP1dqVfb310v0dsNJOxTM.GXgCt49d8a4SXulSyLK2t3PDbMi', 'gbg3Yyg4ZAFmipciSQtECDEs7nMi7xadXljteJ1dsQCAMKN3Dj2oVfhG31hR', '2018-07-26 04:23:35', '2018-07-26 04:23:35'),
(5, 'userThree', 'userThree@gmail.com', '$2y$10$NnuUQQpAddkeDVxx2b91ROTPbj8UENehxd8NVs8XNj9rUMHmAeyh2', 'FtjJOLLeqCJWOrxPKjZYzFzAJdwZqiRny32whAVkWXGW9EcXzp7YPT15G5vY', '2018-07-26 04:24:09', '2018-07-26 04:24:09'),
(6, 'userFour', 'userFour@gmail.com', '$2y$10$pYQZDgPqff3Ie6iWEnsTw.GGUUIZfT7Y8VYj.cjW3HXqNB9rICew.', 'vgQx7zwPBqS9qqhYXYks0fpSdcWPJFgFaiJfMc7nhQNCWMdWlhgNDWtqp3mK', '2018-07-26 04:24:34', '2018-07-26 04:24:34'),
(7, 'userFive', 'userFive@gmail.com', '$2y$10$xTCcYL71/kCdwsDA9sXwku1xO2GwLAsI1HTIwqwZMRagsTlTNMcXy', 'yXYofrk2Jh5vUGJM6RfXembezUnHFzMI51l2KlcujUj64FXyBDIuEWO4fRiK', '2018-07-26 04:25:01', '2018-07-26 04:25:01'),
(8, 'userSix', 'userSix@gmail.com', '$2y$10$8bQ.adHwBX66jRXzps5Qz.JJq..maQUPGa9k4KrfK6/lzGVK523pK', 'c68OvUawSYhR2PfSWmn8rO8NUagEm8xADakXxeZv1LyZXWXULevarHrVhdvt', '2018-07-26 04:25:26', '2018-07-26 04:25:26'),
(9, 'userSeven', 'userSeven@gmail.com', '$2y$10$EL0N3iEIwmRq8GrUF4WGT.na0tk227ZwC8iiuwO00K9wwSYLFs2P6', 'yAFGEVoBe8K1bUnHbt25aQogDE12M5benbtxqYVtYjshzrIyCzHj4ZDPfaa3', '2018-07-26 04:25:52', '2018-07-26 04:25:52'),
(10, 'userEight', 'userEight@gmail.com', '$2y$10$qYruW9BCeoth030OmVAUc.RihqgzuSECHCNuXkv.pVOJuiBUGvADS', 'LODsiyymLcDZ5vAs5gdA2lRKCzBalnP5mDh3zLXSpakO1bqVH1C4jf1LlURy', '2018-07-26 04:26:19', '2018-07-26 04:26:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
